export default DataLoader;
declare const DataLoader: DataLoaderClass;
declare class DataLoaderClass {
    cacheManager: CacheManager;
    sportradarClient: SportradarClient;
    fetchCompetitions(): Promise<any>;
    fetchCompetitionInfo(competitionId: any): Promise<any>;
    /**
     * Fetch schedules for a competitor (team) and convert to internal event shape.
     * Returns an array of event objects similar to client.parseEvent's output.
     */
    fetchCompetitorSchedules(competitorId: any, daysAhead?: number): Promise<{
        home: {
            id: string;
            team: any;
            teamAbbr: any;
            score: string;
            isWinner: boolean;
            isLoser: boolean;
        };
        away: {
            id: string;
            team: any;
            teamAbbr: any;
            score: string;
            isWinner: boolean;
            isLoser: boolean;
        };
        meta: string;
        timestamp: number;
        link: null;
        live: boolean;
        isComplete: boolean;
    }[]>;
    getDynamicConstants(): Promise<{
        PREF_UPDATE_FREQ: string;
        PREF_FOLLOWED_ONLY: string;
        PREF_COMPACT_MODE: string;
        PREF_POSITION_TOPBAR: string;
        PREF_SHOW_NEXT_GAMES: string;
        PREF_LEAGUES: {};
        DISPLAY_NAME: {};
        PREF_TOURNAMENTS: {
            "CONCACAF Gold Cup": string;
            "Copa America": string;
            "FA Cup": string;
            "FIFA World Cup": string;
            "Leagues Cup": string;
            "UEFA Europa Conference League": string;
            "UEFA European Championship": string;
            "UEFA Europa League": string;
            "UEFA Women's Champions League": string;
        };
        SPORTS: {};
    }>;
}
import { CacheManager } from "./cache_manager.js";
import { SportradarClient } from "./sportradar_client.js";
//# sourceMappingURL=data.d.ts.map