/**
 * Load environment variables from .env file
 */
export function loadEnv(): {};
//# sourceMappingURL=env_loader.d.ts.map