declare const ColosseumExtension_base: any;
export default class ColosseumExtension extends ColosseumExtension_base {
    [x: string]: any;
    enable(): Promise<void>;
    scores: any;
    checkForDataUpdates(): Promise<void>;
    disable(): void;
}
export {};
//# sourceMappingURL=extension.d.ts.map