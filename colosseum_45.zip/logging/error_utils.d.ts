/**
 * Set the logger instance for testing or alternative environments.
 *
 * Allows injection of custom loggers for unit testing or different
 * runtime environments. The default logger works with GNOME Shell's
 * logging system.
 *
 * @param logger - Logger implementation to use for all logging functions
 *
 * @example
 * ```typescript
 * // In tests
 * const mockLogger = { log: jest.fn(), logError: jest.fn() };
 * setLogger(mockLogger);
 *
 * logErr('test error');
 * expect(mockLogger.logError).toHaveBeenCalled();
 * ```
 */
export function setLogger(logger: any): void;
/**
 * Log an error message with optional context.
 *
 * For Error objects, logs both the message and stack trace. For other
 * types, converts to string and logs as an error. Includes full error
 * details for debugging.
 *
 * @param error - Error object, string, or other value to log as error
 * @param context - Optional context description for better debugging
 *
 * @example
 * ```typescript
 * try {
 *   parseColorString(invalidColor);
 * } catch (error) {
 *   logErr(error, 'Color parsing');
 * }
 *
 * // Output: [Colosseum] Color parsing: Invalid color format '#gggggg'
 * ```
 */
export function logErr(error: any, context: any): void;
/**
 * Log a warning message with optional context.
 *
 * Used for non-critical issues that should be noted but don't prevent
 * operation. Includes '[WARN]' prefix for easy filtering in logs.
 *
 * @param message - Warning message, error object, or other value to log
 * @param context - Optional context description for better debugging
 *
 * @example
 * ```typescript
 * if (colorValue === fallbackColor) {
 *   logWarn(`Using fallback color ${fallbackColor}`, 'Color validation');
 * }
 *
 * // Output: [WARN] [Colosseum] Color validation: Using fallback color #FFFFFF
 * ```
 */
export function logWarn(message: any, context: any): void;
/**
 * Log an informational message with optional context.
 *
 * Used for general information that may be useful for debugging or
 * monitoring. Includes '[INFO]' prefix for easy filtering in logs.
 *
 * @param message - Information message, error object, or other value to log
 * @param context - Optional context description for better debugging
 *
 * @example
 * ```typescript
 * logInfo(`Extension version ${version} initialized`, 'Startup');
 * logInfo('Settings successfully loaded');
 *
 * // Output: [INFO] [Colosseum] Startup: Extension version 1.2.0 initialized
 * ```
 */
export function logInfo(message: any, context: any): void;
/**
 * Log a debug message with optional context.
 *
 * Used for detailed debugging information that's typically only needed
 * during development or troubleshooting. Includes '[DEBUG]' prefix for
 * easy filtering in logs.
 *
 * @param message - Debug message, error object, or other value to log
 * @param context - Optional context description for better debugging
 *
 * @example
 * ```typescript
 * logDebug(`Processing time: ${hours}:${minutes}`, 'Clock formatting');
 * logDebug('Color mode changed to accent', 'Style service');
 *
 * // Output: [DEBUG] [Colosseum] Clock formatting: Processing time: 14:30
 * ```
 */
export function logDebug(message: any, context: any): void;
/**
 * Validates that a Date object represents a valid date and time.
 *
 * Checks if the provided Date object is valid (not null, undefined, or
 * representing an invalid date like 'new Date("invalid")'). Throws a
 * descriptive error if validation fails.
 *
 * @param date - The Date object to validate
 * @param context - Context description included in error messages
 * @throws Error if the date is null, undefined, or invalid
 *
 * @example
 * ```typescript
 * function updateClock(date: Date) {
 *   validateDate(date, 'Clock update');
 *   // Safe to use date here
 *   const hours = date.getHours();
 * }
 *
 * // This will throw: "Clock update: Invalid date provided"
 * updateClock(new Date('invalid'));
 * ```
 */
export function validateDate(date: any, context?: string): void;
//# sourceMappingURL=error_utils.d.ts.map