export namespace gjsLogger {
    function log(...args: any[]): void;
    function logError(error: any, message: any): void;
}
//# sourceMappingURL=logger_gjs.d.ts.map