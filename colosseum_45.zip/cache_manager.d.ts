/**
 * Manages local file cache for competitions and teams data
 */
export class CacheManager {
    _decoder: TextDecoder;
    data: any;
    /**
     * Load cache from disk
     */
    load(): any;
    /**
     * Save cache to disk
     */
    save(leagues: any, teams: any, rawCompetitions: any): void;
    /**
     * Check if cache needs updating
     */
    shouldUpdate(): boolean;
    /**
     * Get cached competitions
     */
    getRawCompetitions(): any;
    /**
     * Get cached leagues
     */
    getLeagues(): any;
    /**
     * Get cached teams for a league
     */
    getTeams(leagueId: any): any;
}
//# sourceMappingURL=cache_manager.d.ts.map