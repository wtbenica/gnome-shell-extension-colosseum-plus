/**
 * Sportradar API client for soccer data
 */
export class SportradarClient {
    constructor(apiKey: any);
    apiKey: any;
    session: any;
    _decoder: TextDecoder;
    /**
     * Make a GET request to Sportradar API
     */
    request(endpoint: any): Promise<any>;
    /**
     * Fetch all competitions
     */
    getCompetitions(locale?: string): Promise<any>;
    /**
     * Fetch seasons for a competition
     */
    getSeasonsForCompetition(competitionId: any, locale?: string): Promise<any>;
    /**
     * Fetch competitors (teams) for a season
     */
    getCompetitorsForSeason(seasonId: any, locale?: string): Promise<any>;
    /**
     * Fetch competition info including teams
     */
    getCompetitionInfo(competitionId: any, locale?: string): Promise<{
        season: {
            competitors: any;
        };
    } | null>;
    /**
     * Fetch schedules (previous and upcoming) for a competitor
     */
    getCompetitorSchedules(competitorId: any, locale?: string): Promise<any>;
    /**
     * Close the session
     */
    destroy(): void;
}
//# sourceMappingURL=sportradar_client.d.ts.map