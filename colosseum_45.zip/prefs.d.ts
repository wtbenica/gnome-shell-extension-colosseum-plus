declare const ColosseumPreferences_base: any;
export default class ColosseumPreferences extends ColosseumPreferences_base {
    [x: string]: any;
    fillPreferencesWindow(window: any): void;
}
export {};
//# sourceMappingURL=prefs.d.ts.map