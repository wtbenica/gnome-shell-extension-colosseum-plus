export const TeamSelectorDialog: any;
//# sourceMappingURL=team_selector.d.ts.map