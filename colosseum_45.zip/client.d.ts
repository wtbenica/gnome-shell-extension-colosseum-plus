export interface ColosseumConstants {
    PREF_LEAGUES: Record<string, string>;
    PREF_TOURNAMENTS: Record<string, string>;
    SPORTS: Record<string, Array<{
        id: number;
        name: string;
        league?: string;
    }>>;
    PREF_FOLLOWED_ONLY: string;
    PREF_SHOW_NEXT_GAMES: string;
}
export interface Settings {
    get_boolean(key: string): boolean;
    get_strv(key: string): string[];
    get_int?(key: string): number;
}
export default class ColosseumClient {
    private _CONSTANTS;
    private _settings;
    private _leagues;
    private _tournaments;
    constructor(constants: ColosseumConstants, settings: Settings);
    getScores(): Promise<any[]>;
    getNextGames(): Promise<any[]>;
    getEnabledLeagues(): string[];
    getEnabledTournaments(): string[];
    getFollowedTeams(league: string): string[];
    isFollowOnlyEnabled(): boolean;
    isShowNextGamesEnabled(): boolean;
    getAvailableTeams(): Promise<Array<{
        id: number;
        name: string;
        league: string;
    }>>;
}
//# sourceMappingURL=client.d.ts.map