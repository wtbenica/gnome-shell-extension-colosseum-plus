export const GameLink: any;
//# sourceMappingURL=game_link.d.ts.map