export const Colosseum: any;
//# sourceMappingURL=colosseum.d.ts.map