export function getConstants(): Promise<any>;
export const PREF_UPDATE_FREQ: "update-frequency";
export const PREF_FOLLOWED_ONLY: "followed-only";
export const PREF_COMPACT_MODE: "compact-mode";
export const PREF_POSITION_TOPBAR: "position-in-topbar";
export const PREF_SHOW_NEXT_GAMES: "show-next-games";
export let PREF_LEAGUES: {
    Bund: string;
    Bund2: string;
    UCL: string;
    "English League Championship": string;
    EPL: string;
    ISR: string;
    L1: string;
    LaLiga: string;
    LaLigaMX: string;
    "Ligue 1": string;
    MLS: string;
    "Serie A": string;
    WNBA: string;
};
export let DISPLAY_NAME: {
    Bund: string;
    Bund2: string;
    UCL: string;
    "English League Championship": string;
    EPL: string;
    ISR: string;
    L1: string;
    LaLiga: string;
    LaLigaMX: string;
    "Ligue 1": string;
    MLS: string;
    "Serie A": string;
    WNBA: string;
};
export let PREF_TOURNAMENTS: {
    "CONCACAF Gold Cup": string;
    "Copa America": string;
    "FA Cup": string;
    "FIFA World Cup": string;
    "Leagues Cup": string;
    "UEFA Europa Conference League": string;
    "UEFA European Championship": string;
    "UEFA Europa League": string;
    "UEFA Women's Champions League": string;
};
export let SPORTS: {};
//# sourceMappingURL=const.d.ts.map